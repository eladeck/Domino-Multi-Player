import React from 'react';
import ConverssionArea from './converssionArea';
import ChatInput from './chatInput';

export default function() {               
    return(
        <div className="chat-contaier">
            <ConverssionArea />
            <ChatInput />
        </div>
    )

    
}